<?php defined('BASEPATH') || exit('No direct script access allowed');

/**
 * Prospect controller
 */
class Prospect extends Front_Controller
{
    protected $permissionCreate = 'Prospect.Prospect.Create';
    protected $permissionDelete = 'Prospect.Prospect.Delete';
    protected $permissionEdit   = 'Prospect.Prospect.Edit';
    protected $permissionView   = 'Prospect.Prospect.View';

    /**
     * Constructor
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->library('users/auth');
        $this->set_current_user();
       // if ($this->auth->is_logged_in()) {

        $this->load->model('prospect/prospect_model');
        $this->lang->load('prospect');
        Assets::add_module_js('prospect', 'prospect.js');
        Assets::add_js('pagination.min.js');
        Assets::add_css('pagination');
        //}         else {                $this->current_user = null;            }
    }

    /**
     * Display a list of prospect data.
     *
     * @return void
     */
    public function index()
    {
        
        $records = $this->prospect_model->find_all();

        Template::set('records', $records);
        
        Template::render();
    }

    public function ajax_index()
    {
        $offset = isset($_GET['pageNumber'])?$_GET['pageNumber']:0 ;
        $limit = isset($_GET['pageSize'])?$_GET['pageSize']:2 ;
        $this->prospect_model->limit($limit,$offset);
        $records = $this->prospect_model->find_all();
        echo json_encode( $records);
        //Template::render();
    }
    
}