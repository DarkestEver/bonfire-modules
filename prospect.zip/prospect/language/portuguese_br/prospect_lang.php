<?php defined('BASEPATH') || exit('No direct script access allowed');

$lang['prospect_manage']      = 'Gerenciar prospect';
$lang['prospect_edit']        = 'Editar';
$lang['prospect_true']        = 'Verdadeiro';
$lang['prospect_false']       = 'Falso';
$lang['prospect_create']      = 'Criar';
$lang['prospect_list']        = 'Listar';
$lang['prospect_new']       = 'Novo';
$lang['prospect_edit_text']     = 'Edite isto conforme sua necessidade';
$lang['prospect_no_records']    = 'Não há prospect no sistema.';
$lang['prospect_create_new']    = 'Criar novo(a) prospect.';
$lang['prospect_create_success']  = 'prospect Criado(a) com sucesso.';
$lang['prospect_create_failure']  = 'Ocorreu um problema criando o(a) prospect: ';
$lang['prospect_create_new_button'] = 'Criar novo(a) prospect';
$lang['prospect_invalid_id']    = 'ID de prospect inválida.';
$lang['prospect_edit_success']    = 'prospect salvo(a) com sucesso.';
$lang['prospect_edit_failure']    = 'Ocorreu um problema salvando o(a) prospect: ';
$lang['prospect_delete_success']  = 'Registro(s) excluído(s) com sucesso.';
$lang['prospect_delete_failure']  = 'Não foi possível excluir o registro: ';
$lang['prospect_delete_error']    = 'Voc6e não selecionou nenhum registro para excluir.';
$lang['prospect_actions']     = 'Ações';
$lang['prospect_cancel']      = 'Cancelar';
$lang['prospect_delete_record']   = 'Excluir este(a) prospect';
$lang['prospect_delete_confirm']  = 'Você tem certeza que deseja excluir este(a) prospect?';
$lang['prospect_edit_heading']    = 'Editar prospect';

// Create/Edit Buttons
$lang['prospect_action_edit']   = 'Salvar prospect';
$lang['prospect_action_create']   = 'Criar prospect';

// Activities
$lang['prospect_act_create_record'] = 'Criado registro com ID';
$lang['prospect_act_edit_record'] = 'Atualizado registro com ID';
$lang['prospect_act_delete_record'] = 'Excluído registro com ID';

//Listing Specifics
$lang['prospect_records_empty']    = 'Nenhum registro encontrado.';
$lang['prospect_errors_message']    = 'Por favor corrija os erros a seguir:';

// Column Headings
$lang['prospect_column_created']  = 'Criado';
$lang['prospect_column_deleted']  = 'Excluído';
$lang['prospect_column_modified'] = 'Atualizado';

// Module Details
$lang['prospect_module_name'] = 'prospect';
$lang['prospect_module_description'] = 'Your module description';
$lang['prospect_area_title'] = 'prospect';

// Fields
$lang['prospect_field_firstname'] = 'First Name';
$lang['prospect_field_lastname'] = 'Last Name';
