<?php defined('BASEPATH') || exit('No direct script access allowed');


$lang['prospect_manage']      = 'Manage prospect';
$lang['prospect_edit']        = 'Edit';
$lang['prospect_true']        = 'True';
$lang['prospect_false']       = 'False';
$lang['prospect_create']      = 'Create';
$lang['prospect_list']        = 'List';
$lang['prospect_new']       = 'New';
$lang['prospect_edit_text']     = 'Edit this to suit your needs';
$lang['prospect_no_records']    = 'There are no prospect in the system.';
$lang['prospect_create_new']    = 'Create a new prospect.';
$lang['prospect_create_success']  = 'prospect successfully created.';
$lang['prospect_create_failure']  = 'There was a problem creating the prospect: ';
$lang['prospect_create_new_button'] = 'Create New prospect';
$lang['prospect_invalid_id']    = 'Invalid prospect ID.';
$lang['prospect_edit_success']    = 'prospect successfully saved.';
$lang['prospect_edit_failure']    = 'There was a problem saving the prospect: ';
$lang['prospect_delete_success']  = 'record(s) successfully deleted.';
$lang['prospect_delete_failure']  = 'We could not delete the record: ';
$lang['prospect_delete_error']    = 'You have not selected any records to delete.';
$lang['prospect_actions']     = 'Actions';
$lang['prospect_cancel']      = 'Cancel';
$lang['prospect_delete_record']   = 'Delete this prospect';
$lang['prospect_delete_confirm']  = 'Are you sure you want to delete this prospect?';
$lang['prospect_edit_heading']    = 'Edit prospect';

// Create/Edit Buttons
$lang['prospect_action_edit']   = 'Save prospect';
$lang['prospect_action_create']   = 'Create prospect';

// Activities
$lang['prospect_act_create_record'] = 'Created record with ID';
$lang['prospect_act_edit_record'] = 'Updated record with ID';
$lang['prospect_act_delete_record'] = 'Deleted record with ID';

//Listing Specifics
$lang['prospect_records_empty']    = 'No records found that match your selection.';
$lang['prospect_errors_message']    = 'Please fix the following errors:';

// Column Headings
$lang['prospect_column_created']  = 'Created';
$lang['prospect_column_deleted']  = 'Deleted';
$lang['prospect_column_modified'] = 'Modified';
$lang['prospect_column_deleted_by'] = 'Deleted By';
$lang['prospect_column_created_by'] = 'Created By';
$lang['prospect_column_modified_by'] = 'Modified By';

// Module Details
$lang['prospect_module_name'] = 'prospect';
$lang['prospect_module_description'] = 'Your module description';
$lang['prospect_area_title'] = 'prospect';

// Fields
$lang['prospect_field_firstname'] = 'First Name';
$lang['prospect_field_lastname'] = 'Last Name';