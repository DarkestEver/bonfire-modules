<?php defined('BASEPATH') || exit('No direct script access allowed');

$lang['prospect_manage']      = 'Gestionar prospect';
$lang['prospect_edit']        = 'Editar';
$lang['prospect_true']        = 'Verdadero';
$lang['prospect_false']       = 'Falso';
$lang['prospect_create']      = 'Crear';
$lang['prospect_list']        = 'Listar';
$lang['prospect_new']       = 'Nuevo';
$lang['prospect_edit_text']     = 'Editar esto para satisfacer sus necesidades';
$lang['prospect_no_records']    = 'Hay ninguna prospect en la sistema.';
$lang['prospect_create_new']    = 'Crear nuevo(a) prospect.';
$lang['prospect_create_success']  = 'prospect creado(a) con éxito.';
$lang['prospect_create_failure']  = 'Hubo un problema al crear el(la) prospect: ';
$lang['prospect_create_new_button'] = 'Crear nuevo(a) prospect';
$lang['prospect_invalid_id']    = 'ID de prospect inválido(a).';
$lang['prospect_edit_success']    = 'prospect guardado correctamente.';
$lang['prospect_edit_failure']    = 'Hubo un problema guardando el(la) prospect: ';
$lang['prospect_delete_success']  = 'Registro(s) eliminado con éxito.';
$lang['prospect_delete_failure']  = 'No hemos podido eliminar el registro: ';
$lang['prospect_delete_error']    = 'No ha seleccionado ning&#250;n registro que desea eliminar.';
$lang['prospect_actions']     = 'Açciones';
$lang['prospect_cancel']      = 'Cancelar';
$lang['prospect_delete_record']   = 'Eliminar este(a) prospect';
$lang['prospect_delete_confirm']  = '¿Esta seguro de que desea eliminar este(a) prospect?';
$lang['prospect_edit_heading']    = 'Editar prospect';

// Create/Edit Buttons
$lang['prospect_action_edit']   = 'Guardar prospect';
$lang['prospect_action_create']   = 'Crear prospect';

// Activities
$lang['prospect_act_create_record'] = 'Creado registro con ID';
$lang['prospect_act_edit_record'] = 'Actualizado registro con ID';
$lang['prospect_act_delete_record'] = 'Eliminado registro con ID';

//Listing Specifics
$lang['prospect_records_empty']    = 'No hay registros encontrados para su selección.';
$lang['prospect_errors_message']    = 'Por favor corrija los siguientes errores:';

// Column Headings
$lang['prospect_column_created']  = 'Creado';
$lang['prospect_column_deleted']  = 'Elíminado';
$lang['prospect_column_modified'] = 'Modificado';

// Module Details
$lang['prospect_module_name'] = 'prospect';
$lang['prospect_module_description'] = 'Your module description';
$lang['prospect_area_title'] = 'prospect';

// Fields
$lang['prospect_field_firstname'] = 'First Name';
$lang['prospect_field_lastname'] = 'Last Name';
