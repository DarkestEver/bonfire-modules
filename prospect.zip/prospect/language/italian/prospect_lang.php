<?php defined('BASEPATH') || exit('No direct script access allowed');

$lang['prospect_manage']      = 'Gestisci prospect';
$lang['prospect_edit']        = 'Modifica';
$lang['prospect_true']        = 'Vero';
$lang['prospect_false']       = 'Falso';
$lang['prospect_create']      = 'Crea';
$lang['prospect_list']        = 'Elenca';
$lang['prospect_new']       = 'Nuovo';
$lang['prospect_edit_text']     = 'Modifica questo secondo le tue necessità';
$lang['prospect_no_records']    = 'Non ci sono prospect nel sistema.';
$lang['prospect_create_new']    = 'Crea un nuovo prospect.';
$lang['prospect_create_success']  = 'prospect creato con successo.';
$lang['prospect_create_failure']  = 'C\'è stato un problema nella creazione di prospect: ';
$lang['prospect_create_new_button'] = 'Crea nuovo prospect';
$lang['prospect_invalid_id']    = 'ID prospect non valido.';
$lang['prospect_edit_success']    = 'prospect creato con successo.';
$lang['prospect_edit_failure']    = 'C\'è stato un errore nel salvataggio di prospect: ';
$lang['prospect_delete_success']  = 'record(s) creati con successo.';
$lang['prospect_delete_failure']  = 'Non possiamo eliminare il record: ';
$lang['prospect_delete_error']    = 'Non hai selezionato alcun record da eliminare.';
$lang['prospect_actions']     = 'Azioni';
$lang['prospect_cancel']      = 'Cancella';
$lang['prospect_delete_record']   = 'Elimina questo prospect';
$lang['prospect_delete_confirm']  = 'Sei sicuro di voler eliminare questo prospect?';
$lang['prospect_edit_heading']    = 'Modifica prospect';

// Create/Edit Buttons
$lang['prospect_action_edit']   = 'Salva prospect';
$lang['prospect_action_create']   = 'Crea prospect';

// Activities
$lang['prospect_act_create_record'] = 'Creato il record con ID';
$lang['prospect_act_edit_record'] = 'Aggiornato il record con ID';
$lang['prospect_act_delete_record'] = 'Eliminato il record con ID';

// Listing Specifics
$lang['prospect_records_empty']    = 'Nessun record trovato che corrisponda alla tua selezione.';
$lang['prospect_errors_message']    = 'Per favore risolvi i seguenti errori:';

// Column Headings
$lang['prospect_column_created']  = 'Creato';
$lang['prospect_column_deleted']  = 'Eliminato';
$lang['prospect_column_modified'] = 'Modificato';

// Module Details
$lang['prospect_module_name'] = 'prospect';
$lang['prospect_module_description'] = 'Your module description';
$lang['prospect_area_title'] = 'prospect';

// Fields
$lang['prospect_field_firstname'] = 'First Name';
$lang['prospect_field_lastname'] = 'Last Name';
