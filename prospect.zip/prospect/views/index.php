<?php

$hiddenFields = array('id',);
?>
<h1 class='page-header'>
    <?php echo lang('prospect_area_title'); ?>
</h1>

<div class="span12">

<div class="span2">
		<select class="your-select-box" multiple="multiple">
			<option>1</option>
			<option>2</option>
	</select>
</div>	
<div class="span2">
		<select class="your-select-box" multiple="multiple">
			<option>1</option>
			<option>2</option>
	</select>
</div>	
<div class="span2">
		<select class="your-select-box" multiple="multiple">
			<option>1</option>
			<option>2</option>
	</select>
</div>	
<div class="span2">
		<select class="your-select-box" multiple="multiple">
			<option>1</option>
			<option>2</option>
	</select>
</div>	
<div class="span2">
		<select class="your-select-box" multiple="multiple">
			<option>1</option>
			<option>2</option>
	</select>
</div>	
<div class="span1">
<button>search</button>
</div>	


</div>
<?php if (isset($records) && is_array($records) && count($records)) : ?>
		

<div class="span12">
        <div class="data-container"></div>
        <div id="pagination-demo2"></div>
        <input type="hidden" name="" id="hidden1_query" value="firstname=2" />
<?php
endif; ?>

</div>


