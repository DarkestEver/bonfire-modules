<?php

$hiddenFields = array('id',);
?>
<h1 class='page-header'>
    <?php echo lang('prospect_area_title'); ?>
</h1>
<?php if (isset($records) && is_array($records) && count($records)) : ?>
		

		
        <div class="data-container"></div>
        <div id="pagination-demo2"></div>
        <input type="hidden" name="" id="hidden1_query" value="firstname=2" />


<?php
endif; ?>