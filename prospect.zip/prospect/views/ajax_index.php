<?php if (isset($records) && is_array($records) && count($records)) : ?>

$(function() {
  

  (function(name) {
    var container = $('#pagination-' + name);
    container.pagination({
      dataSource: '',
      locator: 'items',
      totalNumber: <?php echo count($records);?>,
      pageSize: 20,
      
      ajax: {
        beforeSend: function() {
          container.prev().html('Loading data ...');
        }
      },
      callback: function(response, pagination) {
        
        var dataHtml = '<ul>';

        $.each(response, function (index, item) {
          dataHtml += '<li>' + item.firstname + '</li>';
        });

        dataHtml += '</ul>';

        container.prev().html(dataHtml);
      }
    })
  })('demo2');
})


<?php

endif; ?>