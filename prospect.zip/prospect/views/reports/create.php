<?php

if (validation_errors()) :
?>
<div class='alert alert-block alert-error fade in'>
    <a class='close' data-dismiss='alert'>&times;</a>
    <h4 class='alert-heading'>
        <?php echo lang('prospect_errors_message'); ?>
    </h4>
    <?php echo validation_errors(); ?>
</div>
<?php
endif;

$id = isset($prospect->id) ? $prospect->id : '';

?>
<div class='admin-box'>
    <h3>prospect</h3>
    <?php echo form_open($this->uri->uri_string(), 'class="form-horizontal"'); ?>
        <fieldset>
            

            <div class="control-group<?php echo form_error('firstname') ? ' error' : ''; ?>">
                <?php echo form_label(lang('prospect_field_firstname'), 'firstname', array('class' => 'control-label')); ?>
                <div class='controls'>
                    <input id='firstname' type='text' name='firstname'  value="<?php echo set_value('firstname', isset($prospect->firstname) ? $prospect->firstname : ''); ?>" />
                    <span class='help-inline'><?php echo form_error('firstname'); ?></span>
                </div>
            </div>

            <div class="control-group<?php echo form_error('lastname') ? ' error' : ''; ?>">
                <?php echo form_label(lang('prospect_field_lastname'), 'lastname', array('class' => 'control-label')); ?>
                <div class='controls'>
                    <input id='lastname' type='text' name='lastname'  value="<?php echo set_value('lastname', isset($prospect->lastname) ? $prospect->lastname : ''); ?>" />
                    <span class='help-inline'><?php echo form_error('lastname'); ?></span>
                </div>
            </div>
        </fieldset>
        <fieldset class='form-actions'>
            <input type='submit' name='save' class='btn btn-primary' value="<?php echo lang('prospect_action_create'); ?>" />
            <?php echo lang('bf_or'); ?>
            <?php echo anchor(SITE_AREA . '/reports/prospect', lang('prospect_cancel'), 'class="btn btn-warning"'); ?>
            
        </fieldset>
    <?php echo form_close(); ?>
</div>