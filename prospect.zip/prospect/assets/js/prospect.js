$(function() {
  

  (function(name) {
    var filterquery = $("#hidden1_query").val();
    var container = $('#pagination-' + name);
    container.pagination({
      dataSource: 'prospect/ajax_index?' + filterquery,
      locator: 'items',
      pageNumber: 0,
      totalNumber: 6,
      pageSize:2,

      ajax: {
        beforeSend: function() {
          container.prev().html('Loading data ...');
        }
      },
      callback: function(response, pagination) {
        var th = "";
        var  obj_colname = Object.keys(response[0]);
        for (x=0;x<obj_colname.length;x++ )
        {
          th += "<th>" + obj_colname[x] + "</th>";
        }
        var dataHtml = '<table class="table table-bordered table-striped"><thead> '+ th +'</tr></thead><tbody>';
        $.each(response, function (index, item) {
            var td = "";
            var  obj_rowvalues = Object.values(item);
            for (x=0;x<obj_rowvalues.length;x++ )
            {
              td += "<td>" + obj_rowvalues[x] + "</td>";
            }
          dataHtml += '<tr>' +  td  +'</tr>';
        });
        dataHtml += '</tbody></table>';
        container.prev().html(dataHtml);
      }
    })
  })('demo2');
})